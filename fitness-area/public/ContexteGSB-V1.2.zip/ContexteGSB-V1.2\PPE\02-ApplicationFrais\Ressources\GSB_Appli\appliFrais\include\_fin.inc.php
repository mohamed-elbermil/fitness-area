<?php
/** 
 * Lib�re les ressources n�cessaires au fonctionnement de l'application
 * @package default
 * @todo  RAS
 */
    deconnecterServeurBD($idConnexion);
?>